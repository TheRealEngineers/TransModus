create
    definer = sql9630816@`%` function fn_dollarsign(fare decimal(19, 4)) returns varchar(32)
BEGIN
    DECLARE dollar VARCHAR(32);
    
    SET dollar = "$" + fare;
    
    RETURN dollar;
END;


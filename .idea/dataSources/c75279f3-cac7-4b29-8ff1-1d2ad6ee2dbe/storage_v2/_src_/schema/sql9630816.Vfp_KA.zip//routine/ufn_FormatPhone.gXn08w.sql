create
    definer = sql9630816@`%` function ufn_FormatPhone(PhoneNumber varchar(32)) returns varchar(32)
BEGIN
    DECLARE
        Phone VARCHAR(32) ; DECLARE i INT ;
    SET
        Phone = PhoneNumber ; -- Cleanse phone number string
    SET
        i = 1 ; WHILE i <= LENGTH(PhoneNumber)
    DO
        IF SUBSTRING(PhoneNumber, i, 1) REGEXP '[0-9]' THEN
    SET
        Phone = CONCAT(
            Phone,
            SUBSTRING(PhoneNumber, i, 1)
        ) ;
END IF ;
SET
    i = i + 1 ;
END WHILE ; -- Skip foreign phones
IF SUBSTRING(Phone, 1, 1) IN('1', '+', '0') AND LENGTH(Phone) > 11 THEN
SET
    PhoneNumber = Phone ; ELSE
SET
    PhoneNumber = CONCAT(
        '(',
        SUBSTRING(Phone, 1, 3),
        ') ',
        SUBSTRING(Phone, 4, 3),
        '-',
        SUBSTRING(Phone, 7, 4)
    ) ;
END IF ;

IF PhoneNumber = '() -' THEN
SET
	PhoneNumber = NULL;
END IF;

RETURN PhoneNumber ;
END;


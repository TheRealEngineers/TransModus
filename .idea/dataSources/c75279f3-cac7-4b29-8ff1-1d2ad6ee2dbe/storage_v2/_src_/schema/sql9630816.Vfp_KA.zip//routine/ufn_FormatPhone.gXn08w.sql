create
    definer = sql9630816@`%` function ufn_FormatPhone(PhoneNumber varchar(32)) returns varchar(32)
BEGIN
    DECLARE Phone VARCHAR(32);

    SET Phone = PhoneNumber;

    -- Cleanse phone number string
    WHILE REGEXP_INSTR(PhoneNumber, '[^0-9]') > 0 DO
        SET PhoneNumber = REPLACE(PhoneNumber, SUBSTRING(PhoneNumber, REGEXP_INSTR(PhoneNumber, '[^0-9]'), 1), '');
    END WHILE;

    -- Skip foreign phones
    SET PhoneNumber = IF(SUBSTRING(PhoneNumber, 1, 1) IN ('1', '+', '0') AND CHAR_LENGTH(PhoneNumber) > 11, Phone,
                         CONCAT('(', SUBSTRING(PhoneNumber, 1, 3), ') ', SUBSTRING(PhoneNumber, 4, 3), '-',
                                SUBSTRING(PhoneNumber, 7, 4)));

    -- Add extension if applicable
    SET PhoneNumber = IF(CHAR_LENGTH(Phone) - 10 > 1, CONCAT(PhoneNumber, ' X', SUBSTRING(Phone, 11, CHAR_LENGTH(Phone) - 10)),
               PhoneNumber);

    RETURN PhoneNumber;
END;


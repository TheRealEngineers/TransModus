create
    definer = sql9630816@`%` function fn_access(admin_access tinyint(1)) returns varchar(3)
BEGIN
    DECLARE access VARCHAR(3);
    
    IF admin_access = 0 THEN
        SET access = 'NO';
    ELSEIF admin_access = 1 THEN
        SET access = 'YES';
    END IF;
    
    RETURN access;
END;


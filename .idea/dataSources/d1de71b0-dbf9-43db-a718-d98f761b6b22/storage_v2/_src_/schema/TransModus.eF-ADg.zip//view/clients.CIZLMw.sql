create definer = root@localhost view clients as
select lpad(`transmodus`.`client`.`client_id`, 5, '0')                  AS `user_id`,
       `transmodus`.`client`.`name`                                     AS `name`,
       `transmodus`.`client`.`login`                                    AS `username`,
       `transmodus`.`client`.`email`                                    AS `email`,
       `transmodus`.`client`.`password`                                 AS `password`,
       concat(upper(left(`transmodus`.`client`.`birthday_month`, 1)),
              lower(substr(`transmodus`.`client`.`birthday_month`, 2))) AS `birthday_month`,
       `transmodus`.`client`.`birthday_day`                             AS `birthday_day`,
       `transmodus`.`client`.`birthday_year`                            AS `birthday_year`
from `transmodus`.`client`
where (`transmodus`.`client`.`email` <> '');

